import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../logic/game_engine.dart';
import '../models/gem.dart';

class GameScreen extends StatelessWidget {
  const GameScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (_) => GameEngine(),
      child: Scaffold(
        backgroundColor: const Color(0xFF121212),
        body: SafeArea(
          child: Column(
            children: [
              _buildHeader(),
              Expanded(child: _buildBoard()),
              _buildFooter(),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Consumer<GameEngine>(
      builder: (context, engine, child) => Padding(
        padding: const EdgeInsets.all(20),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            _statColumn("MOVES", engine.movesLeft.toString(), Colors.orange),
            _statColumn("SCORE", engine.score.toString(), Colors.white),
            _statColumn("GOAL", engine.targetScore.toString(), Colors.green),
          ],
        ),
      ),
    );
  }

  Widget _statColumn(String label, String val, Color color) {
    return Column(
      children: [
        Text(label, style: const TextStyle(color: Colors.grey, fontWeight: FontWeight.bold)),
        Text(val, style: TextStyle(color: color, fontSize: 24, fontWeight: FontWeight.w900)),
      ],
    );
  }

  Widget _buildBoard() {
    return AspectRatio(
      aspectRatio: 1,
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: Consumer<GameEngine>(
          builder: (context, engine, child) {
            return GridView.builder(
              physics: const NeverScrollableScrollPhysics(),
              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: engine.cols,
                mainAxisSpacing: 4,
                crossAxisSpacing: 4,
              ),
              itemCount: engine.rows * engine.cols,
              itemBuilder: (context, index) {
                int r = index ~/ engine.cols;
                int c = index % engine.cols;
                return _GemWidget(r: r, c: c, gem: engine.board[r][c]);
              },
            );
          },
        ),
      ),
    );
  }

  Widget _buildFooter() {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 20),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          _powerUpIcon(Icons.gavel, "Hammer"),
          _powerUpIcon(Icons.cyclone, "Shuffle"),
          _powerUpIcon(Icons.brightness_7, "Bomb"),
        ],
      ),
    );
  }

  Widget _powerUpIcon(IconData icon, String label) {
    return Column(
      children: [
        CircleAvatar(backgroundColor: Colors.blueGrey[800], child: Icon(icon, color: Colors.white)),
        const SizedBox(height: 5),
        Text(label, style: const TextStyle(color: Colors.white, fontSize: 10)),
      ],
    );
  }
}

class _GemWidget extends StatelessWidget {
  final int r, c;
  final Gem gem;

  const _GemWidget({required this.r, required this.c, required this.gem});

  @override
  Widget build(BuildContext context) {
    final engine = Provider.of<GameEngine>(context, listen: false);
    return GestureDetector(
      onTap: () {
        if (r < 7) engine.swapGems(r, c, r + 1, c);
      },
      child: Container(
        decoration: BoxDecoration(
          color: const Color(0xFF1E1E1E),
          borderRadius: BorderRadius.circular(8),
        ),
        child: Center(
          child: Container(
            width: 30,
            height: 30,
            decoration: BoxDecoration(
              color: Color(Gem.getColor(gem.type)),
              shape: BoxShape.circle,
              boxShadow: const [BoxShadow(color: Colors.black26, blurRadius: 4, offset: Offset(2, 2))],
            ),
          ),
        ),
      ),
    );
  }
}
