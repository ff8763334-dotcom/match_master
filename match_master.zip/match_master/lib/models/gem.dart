enum GemType { red, blue, green, yellow, purple, orange, empty, rainbow }
enum Special { none, lineHorizontal, lineVertical, bomb }

class Gem {
  GemType type;
  Special special;
  bool isNew;

  Gem({required this.type, this.special = Special.none, this.isNew = false});

  // دالة لتحديد لون الجوهرة بناءً على نوعها
  static dynamic getColor(GemType type) {
    switch (type) {
      case GemType.red: return 0xFFFF4B4B;
      case GemType.blue: return 0xFF1E88E5;
      case GemType.green: return 0xFF43A047;
      case GemType.yellow: return 0xFFFFD600;
      case GemType.purple: return 0xFF8E24AA;
      case GemType.orange: return 0xFFF4511E;
      default: return 0x00000000;
    }
  }
}
