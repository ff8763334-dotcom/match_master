import 'dart:math';
import 'package:flutter/material.dart';
import '../models/gem.dart';

// كلاس مساعد لتحديد إحداثيات الجواهر (الصفوف والأعمدة)
class Point {
  final int x;
  final int y;
  Point(this.x, this.y);
}

class GameEngine extends ChangeNotifier {
  final int rows = 8;
  final int cols = 8;
  late List<List<Gem>> board;
  int score = 0;
  int movesLeft = 30;
  int targetScore = 5000;

  GameEngine() {
    _initBoard();
  }

  // إنشاء لوحة اللعب بشكل عشوائي
  void _initBoard() {
    board = List.generate(rows, (r) => List.generate(cols, (c) => _randomGem()));
    notifyListeners();
  }

  // توليد جوهرة عشوائية
  Gem _randomGem() {
    final types = GemType.values.where((t) => t != GemType.empty && t != GemType.rainbow).toList();
    return Gem(type: types[Random().nextInt(types.length)]);
  }

  // دالة تبديل أماكن الجواهر عند اللمس
  Future<void> swapGems(int r1, int c1, int r2, int c2) async {
    if (movesLeft <= 0) return;
    
    // تبديل مؤقت
    Gem temp = board[r1][c1];
    board[r1][c1] = board[r2][c2];
    board[r2][c2] = temp;

    bool hasMatch = _checkAndResolveMatches();
    if (!hasMatch) {
      // إلغاء التبديل إذا لم يحدث تطابق ثلاثي
      board[r2][c2] = board[r1][c1];
      board[r1][c1] = temp;
    } else {
      movesLeft--;
      await _processCascades();
    }
    notifyListeners();
  }

  // فحص التطابقات الأفقية والعمودية (3 جواهر متشابهة أو أكثر)
  bool _checkAndResolveMatches() {
    List<Point> toRemove = [];
    
    // الفحص الأفقي
    for (int r = 0; r < rows; r++) {
      for (int c = 0; c < cols - 2; c++) {
        if (board[r][c].type == board[r][c+1].type && board[r][c].type == board[r][c+2].type && board[r][c].type != GemType.empty) {
          toRemove.addAll([Point(r, c), Point(r, c+1), Point(r, c+2)]);
        }
      }
    }
    
    // الفحص العمودي
    for (int c = 0; c < cols; c++) {
      for (int r = 0; r < rows - 2; r++) {
        if (board[r][c].type == board[r+1][c].type && board[r][c].type == board[r+2][c].type && board[r][c].type != GemType.empty) {
          toRemove.addAll([Point(r, c), Point(r+1, c), Point(r+2, c)]);
        }
      }
    }
    
    if (toRemove.isEmpty) return false;
    
    // زيادة النقاط
    score += toRemove.length * 10;
    
    // تفريغ المربعات المتطابقة
    for (var p in toRemove) {
      board[p.x][p.y] = Gem(type: GemType.empty);
    }
    return true;
  }

  // نزول الجواهر وتوليد جواهر جديدة للأماكن الفارغة
  Future<void> _processCascades() async {
    bool found;
    do {
      _applyGravity();
      _fillEmpty();
      notifyListeners();
      await Future.delayed(const Duration(milliseconds: 300));
      found = _checkAndResolveMatches();
    } while (found);
  }

  // الجاذبية: سحب الجواهر للأسفل إذا وجد مربع فارغ
  void _applyGravity() {
    for (int c = 0; c < cols; c++) {
      for (int r = rows - 1; r >= 0; r--) {
        if (board[r][c].type == GemType.empty) {
          for (int k = r - 1; k >= 0; k--) {
            if (board[k][c].type != GemType.empty) {
              board[r][c] = board[k][c];
              board[k][c] = Gem(type: GemType.empty);
              break;
            }
          }
        }
      }
    }
  }

  // تعبئة المربعات العلوية المتبقية بجواهر جديدة
  void _fillEmpty() {
    for (int r = 0; r < rows; r++) {
      for (int c = 0; c < cols; c++) {
        if (board[r][c].type == GemType.empty) {
          board[r][c] = _randomGem();
        }
      }
    }
  }
}
